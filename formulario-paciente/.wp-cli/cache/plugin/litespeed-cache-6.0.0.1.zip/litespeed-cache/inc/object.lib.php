<?php

// A compatibility placeholder for v2.9.9- when upgrading to v3 require_once $lscwp_dir . 'inc/object.lib.php' ;
