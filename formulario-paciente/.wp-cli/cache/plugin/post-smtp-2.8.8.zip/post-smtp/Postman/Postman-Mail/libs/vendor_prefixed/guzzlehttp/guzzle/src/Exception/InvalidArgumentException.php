<?php

namespace PostSMTP\Vendor\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements \PostSMTP\Vendor\GuzzleHttp\Exception\GuzzleException
{
}
